#!/usr/bin/env python
import os
import time
path = os.getcwd()
path = os.path.join(path, os.pardir)
os.chdir(os.path.abspath(path))
curr_dir = os.getcwd()
bashfile = fr'{curr_dir}/utilities/installer.sh'
chrome_loc = fr'{curr_dir}/utilities/google-chrome-stable_current_amd64.deb'
if os.path.isfile(bashfile):
    os.system(f'sudo {bashfile}')
    os.remove(bashfile)
    os.remove(chrome_loc)
    time.sleep(10)
from seleniumwire import webdriver
import re
import random
from selenium.webdriver.chrome.options import Options
from imap_tools import MailBox
from imap_tools import A, AND
import sys
dict = fr'{curr_dir}/utilities'
sys.path.insert(1, dict)
from core import Predefined, Proxy

Description = """<p><iframe src="https://www.youtube.com/embed/-grLLLTza6k" frameborder="0" allowfullscreen=""></iframe></p><p><img src="https://images-na.ssl-images-amazon.com/images/I/71Zxjh0AdpL.png" style="width:100%;max-width:450px;clear:both;"></p><p></p><h2>10 Undeniable Reasons People Hate cheats</h2><p></p><p><a href="http://google.com">google</a>If you are questioning concerning utilizing a video game rip off to bump your online, computer system or computer game playing there are great deals of resources available to you. When you are very first beginning to play a game, particularly an on the internet game, you may be annoyed by your lack of skills as well as experience. You could be matched against a lot more seasoned players that benefit from you lack of expertise and abilities to beat you. A video game cheat program could also out the playing field. On the net you can download and install video game cheat software which will certainly offer you the rip off codes and other information that you will have to make you competitive with the most effective gamers.</p><p>It takes a great deal of time and patience to learn most of the on-line video games and also computer game on the market today. The majority of people do not have the time or persistence to do that, but they enjoy playing. When you play on the internet you will certainly be matched versus gamers that have accessibility to the video game cheat codes and software application currently. Give yourself that advantage by obtaining the codes and also software program on your own.</p><p>It is very easy to find a rip off program for nearly any game. You merely key in "game cheat" on your online search engine and "voila" an entire list of websites will turn up. Numerous of these websites supply cost-free trials of the software program so that you could attempt it out before you acquire it. Individuals you are betting will not have any indicator that you are making use of game rip off software application. Not just do these on the internet business supply game cheat codes for online video games but additionally games for systems like PS 2, X-Box, and the Video game Cube. The lists as well as codes are regularly being updated as brand-new video games and variations of video games appear.</p><p>A great deal of the on-line game cheat software program is interactive. You simply put it on before you start to play and also it will certainly tell you concerning upcoming chances as well as challenges as well as evaluating your challenger's relocate to tell you how to counter them. You could discover covert treasures, powers, as well as residential or commercial properties. If you like you can even most likely to various cheat code websites to try various software to understand which one you like the most effective.</p><p>No person prefers to lose. It is simply a video game, yet winning is still the things. Make on your own equivalent to your opponents and make the most of all the devices that are offered to you. As you improve you can count on them much less as well as on your own skills a lot more. It will get you going.<a href="http://yahoo.com">yahoo</a></p><p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13007070.354009148!2d-104.65387033028972!3d37.25828124582162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sus!4v1509017967634" frameborder="0" allowfullscreen=""></iframe></p>"""
Title = '''A Good Title for My Blog'''
Keyword = 'Weight Loss Tips'
proxy = '69.172.232.75'
port = '43222'
proxyU = 'gacott'
proxyP = 'tPGbKdgz'
Blog_Title = "A Good Title of My Blog"
username = f'helloworld100{random.randint(0000,9999)}'
email = f'{username}@164news.com'
password = 'Sunny123'
password = f'{password}A1$'
visibility = 'Onscreen'

pluginloc = ''
options = Options()
options.add_argument("--no-sandbox")
options.add_argument("--headless")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--remote-debugging-port=9222")
# if len(proxyU) == 0 and len(proxy) != 0:
#     options.add_argument('--proxy-server=http://%s:%s' % (proxy, port))
# elif len(proxyU) != 0 and len(proxy) != 0:
#     to = Proxy()
#     pluginloc = to.proxy_auth(proxy, port, proxyU, proxyP)
# options.add_extension(pluginloc)
wireoptions = {
    'proxy': {
        'http' : f'http://{proxyU}:{proxyP}@{proxy}:{port}',
        'https' : f'https://{proxyU}:{proxyP}@{proxy}:{port}',
        'no_proxy': 'localhost,127.0.0.1'
    }
}
# options.binary_location = fr'{curr_dir}/utilities/data/chrome'
# options.binary_location = r'/usr/bin/google-chrome-stable'
options.add_experimental_option('prefs', {
     'credentials_enable_service': False,
    'profile': {
        'password_manager_enabled': False,
        'default_content_setting_values.notifications': 2,
        'profile.default_content_setting_values.media_stream_mic': 2,
        'profile.default_content_setting_values.geolocation': 2
        }
    })
options.add_argument("--disable-notifications")
# options.add_argument("start-maximized")
options.add_argument("--disable-blink-features=AutomationControlled")
# options.add_extension(r'C:\Users\sunny\Desktop\G Stack Suite\webRTC.crx')
# driver = webdriver.Chrome(executable_path=fr'{curr_dir}/utilities/chromedriver',
#                              options=options)
driver = webdriver.Chrome(r'/usr/lib/python3/dist-packages/utilities/chromedriver',
                             options=options, seleniumwire_options=wireoptions)
do = Predefined(driver)
if visibility == 'Offscreen':
    driver.set_window_position(10000, 0)
else:
    driver.set_window_position(0, 0)
do.navigate('https://wordpress.com/start/user?ref=logged-out-homepage-lp')
do.waitforelementdisplay('//input[@id="email"]', 20)
do.doclick('//button[contains(@class,"acknowledge-button")]')
time.sleep(1)
do.typeinput('//input[@id="email"]', email)
do.clearText('//input[@id="username"]')
do.typeinput('//input[@id="username"]', username)
do.typeinput('//input[@id="password"]', password)
do.doclick('//button[contains(@class,"acknowledge-button")]')
do.Enter('//input[@id="password"]')
do.waitforelementdisplay('//input[@type="search"]', 20)
time.sleep(1)
do.typeinput('//input[@type="search"]', username)
do.waitforelementdisplay('//*[contains(@class,"domain-suggestion")]//*[contains(text(),"wordpress.com")]', 15)
if do.element_display('//button[contains(@class,"acknowledge-button")]'):
    do.doclick('//button[contains(@class,"acknowledge-button")]')
do.doclick('//*[contains(@class,"domain-suggestion")]//*[contains(text(),"wordpress.com")]')
do.waitforelement('//button[contains(text(),"free")]', 15)
do.doclick('//button[contains(text(),"free")]')
time.sleep(2)
do.waitforelement('//a[@title="Create a New Post"]', 30)
if do.element_display('//a[@title="Create a New Post"]'):
    counter = 0
    value = False
    while value == False or counter == 30:
        with MailBox('mc1.cloudfido.com').login('catch@164news.com', 'Catch#Unknownuser') as mailbox:
            mailbox.folder.set('INBOX')
            msgs = mailbox.fetch(A(AND(from_='donotreply@wordpress.com', text=f'"Activate {username}"'), to=email))
            for msg in msgs:
                message = msg.html
                if len(message) != 0:
                    value = True
                    regex = """(?<=href\=\").+?(?=\")"""
                    ID = re.findall(regex, message)
                else:
                    time.sleep(10)
                    counter += 1
    if len(ID[0]) != 0:
        do.navigate(ID[0])
        do.waitforelementdisplay(
            '//div[contains(@class,"site-setup-list")]//button[contains(@class,"action is-primary")] | //input[@id="usernameOrEmail"]',
            20)
        time.sleep(3)
        if do.element_display('//input[@id="usernameOrEmail"]'):
            do.typeinput('//input[@id="usernameOrEmail"]', 'Email to Enter')
            do.Enter('//input[@id="usernameOrEmail"]')
            do.typeinput('//input[@id="password"]', 'Password to enter')
            do.Enter('//input[@id="usernameOrEmail"]')
            do.waitforelementdisplay(
                '//span[contains(text(),"View Site")] | //a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]',
                20)
        do.doclick('//button[@data-task="blogname_set"]')
        do.waitforelementdisplay('//button[contains(@class,"site-setup-list")]', 10)
        do.doclick('//button[contains(@class,"site-setup-list")]')
        do.waitforelementdisplay('//input[@id="blogname"]', 15)
        time.sleep(2)
        do.selectalldelete('//input[@id="blogname"]')
        do.typeinput('//input[@id="blogname"]', Blog_Title)
        do.doclick('//button[contains(@data-tip-target,"profile-save")]')
        time.sleep(5)
        if do.element_display('//button[contains(@class,"acknowledge-button")]'):
            do.doclick('//button[contains(@class,"acknowledge-button")]')
        do.doclick('//div[contains(@class,"launch-site-button")]/a')
        do.waitforelementdisplay('(//div[contains(@class,"domain-skip-suggestion")])[1]', 15)
        time.sleep(2)
        do.doclick('(//div[contains(@class,"domain-skip-suggestion")])[1]')
        do.waitforelementdisplay('//button[contains(text(),"free")]', 15)
        time.sleep(2)
        do.doclick('//button[contains(text(),"free")]')
        do.waitforelementdisplay(
            '//div[contains(@class,"continue-link")]/button | //button[contains(text(),"wordpress.com")]', 15)
        time.sleep(2)
        do.doclick('//div[contains(@class,"continue-link")]/button')
        do.doclick('//button[contains(text(),"wordpress.com")]')
        do.waitforelementdisplay('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]', 60)
        time.sleep(2)
        value = do.element_display('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]')
        if value == False:
            do.navigate('https://wordpress.com/post/')
        else:
            do.doclick('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]')
        do.waitforelementdisplay('//textarea[@id="post-title-0"] | //button[contains(@class,"guide__forward")]', 25)
        do.switch_frame('//iframe[contains(@src,"wordpress")]')
        if do.element_display('//button[contains(@class,"forward-button")]'):
            do.doclick('//button[contains(@class,"forward-button")]')
            time.sleep(1)
            do.doclick('//button[contains(@class,"forward-button")]')
            time.sleep(1)
            do.doclick('//button[contains(@class,"forward-button")]')
            time.sleep(1)
            value = do.elementcount(
                '//div[contains(@class,"components-guide")]//button[contains(@class,"finish-button")]')
            do.doclick(
                f'(//div[contains(@class,"components-guide")]//button[contains(@class,"finish-button")])[{value}]')
            time.sleep(2)
        do.switch_default()
        do.switch_frame('//div[contains(@class,"is-iframe")]/iframe')
        if do.element_display('//div[contains(@class,"welcome-tour-frame")]//button[contains(text(),"Skip")]'):
            do.doclick('//div[contains(@class,"welcome-tour-frame")]//button[contains(text(),"Skip")]')
            time.sleep(3)
        if do.element_display('//button[@aria-label="Close dialog"]'):
            do.doclick('//button[@aria-label="Close dialog"]')
        do.typeinput('//textarea[@id="post-title-0"]', Title)
        do.doclick('(//button[@aria-label="Add block"])[1]')
        do.waitforelementdisplay('//div[contains(@class,"inserter__search")]//input[@type="search"]', 10)
        do.doclick('//div[contains(@class,"inserter__search")]//input[@type="search"]')
        time.sleep(1)
        do.typeinput('//div[contains(@class,"inserter__search")]//input[@type="search"]', 'HTML')
        do.waitforelementdisplay('//*[contains(@class,"block-list-item-html")]', 5)
        do.doclick('//*[contains(@class,"block-list-item-html")]')
        time.sleep(1)
        # do.copytoclipboard(Description)
        # do.pastetoelement('//textarea[@aria-label="HTML"]')
        do.typeinput('//textarea[@aria-label="HTML"]', Description)
        time.sleep(2)
        do.doclick('//button[contains(@class,"post-publish-panel")]')
        do.waitforelementdisplay('(//button[contains(@class,"post-publish-button")])[2]', 10)
        time.sleep(1)
        do.doclick('(//button[contains(@class,"post-publish-button")])[2]')
        do.waitforelementdisplay('//input[contains(@id,"inspector-text")]', 20)
        if do.element_exist('//input[contains(@id,"inspector-text")]'):
            link = do.ScrapeAttribute('//input[contains(@id,"inspector-text")]', 'value')
            print(f"Success : {link}")
        # do.doclick('//div[contains(@class,"site-setup-list")]//button[contains(@class,"action is-primary")]')
        # do.waitforelementdisplay('//input[@id="blogname"]', 15)
        # time.sleep(2)
        # do.selectalldelete('//input[@id="blogname"]')
        # do.typeinput('//input[@id="blogname"]', Blog_Title)
        # do.doclick('//button[contains(@data-tip-target,"profile-save")]')
        # if do.element_display('//button[contains(@class,"acknowledge-button")]'):
        #     do.doclick('//button[contains(@class,"acknowledge-button")]')
        # do.doclick('//div[contains(@class,"launch-site-button")]/a')
        # do.waitforelementdisplay('(//div[contains(@class,"domain-skip-suggestion")])[1]', 15)
        # time.sleep(2)
        # do.doclick('(//div[contains(@class,"domain-skip-suggestion")])[1]')
        # do.waitforelementdisplay('//button[contains(text(),"free")]', 15)
        # time.sleep(2)
        # do.doclick('//button[contains(text(),"free")]')
        # do.waitforelementdisplay(
        #     '//div[contains(@class,"continue-link")]/button | //button[contains(text(),"wordpress.com")]', 15)
        # time.sleep(2)
        # do.doclick('//div[contains(@class,"continue-link")]/button')
        # do.doclick('//button[contains(text(),"wordpress.com")]')
        # do.waitforelementdisplay('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]', 60)
        # time.sleep(2)
        # value = do.element_display('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]')
        # if value == False:
        #     do.navigate('https://wordpress.com/post/')
        # else:
        #     do.doclick('//a[@title="Create a New Post"] | //a[contains(@href,"block-editor/post")]')
        # do.waitforelementdisplay('//textarea[@id="post-title-0"] | //button[contains(@class,"guide__forward")]', 25)
        # do.switch_frame('//iframe[contains(@src,"wordpress")]')
        # if do.element_display('//button[contains(@class,"forward-button")]'):
        #     do.doclick('//button[contains(@class,"forward-button")]')
        #     time.sleep(1)
        #     do.doclick('//button[contains(@class,"forward-button")]')
        #     time.sleep(1)
        #     do.doclick('//button[contains(@class,"forward-button")]')
        #     time.sleep(1)
        #     value = do.elementcount(
        #         '//div[contains(@class,"components-guide")]//button[contains(@class,"finish-button")]')
        #     do.doclick(
        #         f'(//div[contains(@class,"components-guide")]//button[contains(@class,"finish-button")])[{value}]')
        # time.sleep(2)
        # do.switch_default()
        # do.switch_frame('//div[contains(@class,"is-iframe")]/iframe')
        # if do.element_display('//div[contains(@class,"welcome-tour-frame")]//button[contains(text(),"Skip")]'):
        #     do.doclick('//div[contains(@class,"welcome-tour-frame")]//button[contains(text(),"Skip")]')
        #     time.sleep(3)
        # if do.element_display('//button[@aria-label="Close dialog"]'):
        #     do.doclick('//button[@aria-label="Close dialog"]')
        # do.typeinput('//textarea[@id="post-title-0"]', Title)
        # do.doclick('(//button[@aria-label="Add block"])[1]')
        # do.waitforelementdisplay('//div[contains(@class,"inserter__search")]//input[@type="search"]', 10)
        # do.doclick('//div[contains(@class,"inserter__search")]//input[@type="search"]')
        # time.sleep(1)
        # do.typeinput('//div[contains(@class,"inserter__search")]//input[@type="search"]', 'HTML')
        # do.waitforelementdisplay('//*[contains(@class,"block-list-item-html")]', 5)
        # do.doclick('//*[contains(@class,"block-list-item-html")]')
        # time.sleep(1)
        # do.copytoclipboard(Description)
        # do.pastetoelement('//textarea[@aria-label="HTML"]')
        # time.sleep(2)
        # do.doclick('//button[contains(@class,"post-publish-panel")]')
        # do.waitforelementdisplay('(//button[contains(@class,"post-publish-button")])[2]', 10)
        # time.sleep(1)
        # do.doclick('(//button[contains(@class,"post-publish-button")])[2]')
        # do.waitforelementdisplay('//input[contains(@id,"inspector-text")]', 20)
        # if do.element_exist('//input[contains(@id,"inspector-text")]'):
        #     link = do.ScrapeAttribute('//input[contains(@id,"inspector-text")]', 'value')
        #     print(f"Success : {link}")
        #     link_success = True
driver.close()
driver.quit()
if len(pluginloc) != 0:
    os.remove(pluginloc)
