#!/usr/bin/env python
import os
import time
path = os.getcwd()
path = os.path.join(path, os.pardir)
os.chdir(os.path.abspath(path))
curr_dir = os.getcwd()
# bashfile = fr'{curr_dir}/utilities/installer.sh'
# chrome_loc = fr'{curr_dir}/utilities/google-chrome-stable_current_amd64.deb'
# if os.path.isfile(bashfile):
#     os.system(f'sudo {bashfile}')
#     os.remove(bashfile)
#     os.remove(chrome_loc)
#     time.sleep(10)
from seleniumwire import webdriver
import re
import random
from selenium.webdriver.chrome.options import Options
from imap_tools import MailBox
from imap_tools import A, AND
import sys
dict = fr'{curr_dir}/utilities'
sys.path.insert(1, dict)
from core import Predefined, Proxy
curr_proxy = 'ballance.fidohost.com:4046'
curr_proxy = curr_proxy.split(':')
if len(curr_proxy) == 4:
    proxy = curr_proxy[0]
    port = curr_proxy[1]
    proxyU = curr_proxy[2]
    proxyP = curr_proxy[3]
else:
    proxy = curr_proxy[0]
    port = curr_proxy[1]
Description = """<p><iframe src="https://www.youtube.com/embed/-grLLLTza6k" frameborder="0" allowfullscreen=""></iframe></p><p><img src="https://images-na.ssl-images-amazon.com/images/I/71Zxjh0AdpL.png" style="width:100%;max-width:450px;clear:both;"></p><p></p><h2>10 Undeniable Reasons People Hate cheats</h2><p></p><p><a href="http://google.com">google</a>If you are questioning concerning utilizing a video game rip off to bump your online, computer system or computer game playing there are great deals of resources available to you. When you are very first beginning to play a game, particularly an on the internet game, you may be annoyed by your lack of skills as well as experience. You could be matched against a lot more seasoned players that benefit from you lack of expertise and abilities to beat you. A video game cheat program could also out the playing field. On the net you can download and install video game cheat software which will certainly offer you the rip off codes and other information that you will have to make you competitive with the most effective gamers.</p><p>It takes a great deal of time and patience to learn most of the on-line video games and also computer game on the market today. The majority of people do not have the time or persistence to do that, but they enjoy playing. When you play on the internet you will certainly be matched versus gamers that have accessibility to the video game cheat codes and software application currently. Give yourself that advantage by obtaining the codes and also software program on your own.</p><p>It is very easy to find a rip off program for nearly any game. You merely key in "game cheat" on your online search engine and "voila" an entire list of websites will turn up. Numerous of these websites supply cost-free trials of the software program so that you could attempt it out before you acquire it. Individuals you are betting will not have any indicator that you are making use of game rip off software application. Not just do these on the internet business supply game cheat codes for online video games but additionally games for systems like PS 2, X-Box, and the Video game Cube. The lists as well as codes are regularly being updated as brand-new video games and variations of video games appear.</p><p>A great deal of the on-line game cheat software program is interactive. You simply put it on before you start to play and also it will certainly tell you concerning upcoming chances as well as challenges as well as evaluating your challenger's relocate to tell you how to counter them. You could discover covert treasures, powers, as well as residential or commercial properties. If you like you can even most likely to various cheat code websites to try various software to understand which one you like the most effective.</p><p>No person prefers to lose. It is simply a video game, yet winning is still the things. Make on your own equivalent to your opponents and make the most of all the devices that are offered to you. As you improve you can count on them much less as well as on your own skills a lot more. It will get you going.<a href="http://yahoo.com">yahoo</a></p><p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13007070.354009148!2d-104.65387033028972!3d37.25828124582162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sus!4v1509017967634" frameborder="0" allowfullscreen=""></iframe></p>"""
Title = '''A Good Title for My Blog'''
Keyword = 'Weight Loss Tips'
Blog_Title = "A Good Title of My Blog"
Tags = 'Keyword1, Keyword2'
api = 'ccbc1608282930faf70f764518569b30'
username = f'helloworld100{random.randint(0000,9999)}'
email = f'{username}@164news.com'
password = 'Sunny123'
password = f'{password}A1$'

pluginloc = ''
options = Options()
options.add_argument("--no-sandbox")
options.add_argument("--headless")
options.add_argument("--disable-gpu")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--remote-debugging-port=9222")
if curr_proxy == 4:
    wireoptions = {
    'proxy': {
        'http': f'http://{proxyU}:{proxyP}@{proxy}:{port}',
        'https': f'https://{proxyU}:{proxyP}@{proxy}:{port}',
        'no_proxy': 'localhost,127.0.0.1'

        }
    }
else:
    wireoptions = {
    'proxy': {
        'http': f'http://{proxy}:{port}',
        'https': f'https://{proxy}:{port}',
        'no_proxy': 'localhost,127.0.0.1'
        }
    }
options.add_experimental_option('prefs', {
     'credentials_enable_service': False,
    'profile': {
        'password_manager_enabled': False,
        'default_content_setting_values.notifications': 2,
        'profile.default_content_setting_values.media_stream_mic': 2,
        'profile.default_content_setting_values.geolocation': 2
        }
    })
options.add_argument("--disable-notifications")
options.add_argument("--disable-blink-features=AutomationControlled")
driver = webdriver.Chrome(r'/usr/bin/chromedriver',
                             options=options, seleniumwire_options=wireoptions)
do = Predefined(driver)
do.navigate('https://www.tumblr.com/register')
do.waitforelementdisplay('//input[@name="email"]', 20)
time.sleep(2)
do.typeinput('//input[@name="email"]', email)
do.typeinput('//input[@name="password"]', password)
time.sleep(2)
do.typeinput2('//input[@name="blogName"]', username)
do.doclick('//button[@type="submit"]')
do.waitforelementdisplay('//input[@name="age"]', 10)
do.typeinput('//input[@name="age"]', random.randint(21, 60))
do.doclick('//input[@type="checkbox"]')
do.doclick('//button[@type="submit"]')
do.waitforelementdisplay('//a[@class="link-shrink"] | //button[@mode="primary"]', 20)
if do.element_display('//button[@mode="primary"]'):
    do.doclick('//button[@mode="primary"]')
    do.waitforelementdisplay('(//a[@class="link-shrink"])[1]', 20)
    time.sleep(2)
do.doclick('(//a[@class="link-shrink"])[1]')
time.sleep(2)
do.doclick('(//a[@class="link-shrink"])[2]')
time.sleep(2)
do.doclick('(//a[@class="link-shrink"])[3]')
time.sleep(2)
do.doclick('(//a[@class="link-shrink"])[4]')
time.sleep(2)
do.doclick('(//a[@class="link-shrink"])[5]')
time.sleep(2)
do.doclick('(//button[contains(@class,"onboarding")])[2]')
do.waitforelementdisplay('//button[@aria-label="Resend"]', 40)
if do.element_display('//button[@aria-label="Resend"]'):
    counter = 0
    value = False
    while value == False or counter == 30:
        with MailBox('mc1.cloudfido.com').login('catch@164news.com', 'Catch#Unknownuser') as mailbox:
            mailbox.folder.set('INBOX')
            msgs = mailbox.fetch(A(AND(text='"Verify your email address"'), to=email))
            for msg in msgs:
                message = msg.text
                if len(message) != 0:
                    value = True
                    regex = "https://www.tumblr.com/verify/.*?(?=\n)"
                    ID = re.search(regex, message).group()
                else:
                    time.sleep(10)
                    counter += 1
if len(ID) != 0:
    do.navigate(ID)
    do.waitforelementdisplay('//div[@id="g-recaptcha"]', 20)
    do.recaptchacallback('2 Captcha', api)
    time.sleep(1)
    do.doclick('//button[@id="verify-button"]')
    do.waitforelementdisplay('//h3[@class="congrats"]', 20)
    do.navigate('https://www.tumblr.com/settings/blog/')
    do.waitforelementdisplay('//button[contains(@data-settings-url,"/settings/")]', 20)
    do.doclick('//button[contains(@data-settings-url,"/settings/")]')
    do.waitforelementdisplay('//span[@data-placeholder="Title"]', 20)
    time.sleep(2)
    do.doclick('//span[@data-placeholder="Title"]')
    do.selectalldelete('//span[@data-placeholder="Title"]')
    do.typeinput('//span[@data-placeholder="Title"]', Blog_Title)
    time.sleep(2)
    do.doclick('//input[@id="search_query"]')
    time.sleep(2)
    do.doclick('//button[contains(@class,"save_button")]')
    do.waitforelementdisplay('//button[contains(@data-settings-url,"/settings/")]', 30)
    do.navigate('https://www.tumblr.com/new/text')
    do.waitforelementdisplay('//div[@aria-label="Post title"]', 20)
    time.sleep(2)
    do.switch_frame('//iframe[@title="Post forms"]')
    do.doclick('//div[@aria-label="Post title"]')
    do.typeinput('//div[@aria-label="Post title"]', Title)
    do.doclick('//div[contains(@class,"post-settings")]')
    do.waitforelementdisplay('//select[@name="editorType"]', 5)
    time.sleep(1)
    do.dropdownselect('//select[@name="editorType"]', 'html', 'value')
    do.waitforelementdisplay('//textarea[@aria-label="HTML content"]', 5)
    do.doclick('//textarea[@aria-label="HTML content"]')
    do.typeinput('//textarea[@aria-label="HTML content"]', Description)
    do.typeinput('//div[contains(@aria-label,"tags")]', Tags)
    do.doclick('//button[contains(@class,"create_post_button")]')
    time.sleep(5)
    do.doclick('//button[@aria-label="Account"]')
    do.waitforelementdisplay('//*[contains(@href,"/blog/")]//*[contains(@srcset,"avatar/")]', 10)
    do.doclick('//*[contains(@href,"/blog/")]//*[contains(@srcset,"avatar/")]')
    do.waitforelementdisplay('(//button[@aria-label="More options"])[1]', 20)
    time.sleep(2)
    if do.element_display('(//button[@aria-label="More options"])[1]'):
        link = do.ScrapeAttribute('(//a[contains(@href,"post/")][@role="link"])[1]', 'href')
        print(f"Success : {link}")
        link_success = True
driver.close()
driver.quit()

