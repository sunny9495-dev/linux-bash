from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
from selenium.webdriver.support.select import Select
from selenium.webdriver import ActionChains
import random
import time
import os
import zipfile
import tempfile
import pyperclip
import re
import requests
import html
from lxml import etree
import base64
import urllib

class Predefined():
    def __init__(self, driver):
        self.driver = driver
    def navigate(self, url):
        try:
            self.driver.get(url)
        except:
            return False
    def findelement(self, xpath):
        element = None
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            if element != None:
                return element
        except:
            return False
    def fileexist(self, file):
        element = None
        try:
           element = os.path.isfile(file)
           return element
        except:
            return False
    def waitforelement(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.presence_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def waitforelementdisplay(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.visibility_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def waitforelementenabled(self, xpath, time=20):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.element_to_be_clickable((By.XPATH, xpath)))
        except:
            return False
    def waitforelementdisappear(self, xpath, time):
        try:
            wait = WebDriverWait(self.driver, timeout=time, poll_frequency=0.1,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            wait.until(EC.invisibility_of_element_located((By.XPATH, xpath)))
        except:
            return False
    def element_exist(self, xpath):
        element = None
        try:
            element = len(self.driver.find_elements(By.XPATH, xpath))
            if element != 0:
                return True
        except:
            return False
    def element_display(self, xpath):
        try:
            self.driver.find_element(By.XPATH, xpath).is_displayed()
            return True
        except:
            return False
    def element_enabled(self, xpath):
        try:
            self.driver.find_element(By.XPATH, xpath).is_enabled()
            return True
        except:
            return False
    def doclick(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.click()
        except:
            return False

    def Enter(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.send_keys(Keys.ENTER)
        except:
            return False

    def typeinput(self, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.send_keys(input)
        except:
            return False
    def typeinput2(self, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.clear()
                element.send_keys(input)
        except:
            return False
    def screenshot(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1,100)
            file = f".\\{rand}.png"
            element.screenshot(file)
        except:
            return False
    def dropdownselect(self, xpath, value, type):
        element = None
        try:
            element = Select(self.findelement(xpath))
            if type == 'index':
                element.select_by_index(value)
            elif type == 'value':
                element.select_by_value(value)
            elif type == 'text':
                element.select_by_visible_text(value)
        except:
            return False
    def type_human_delay(self, xpath, input, minspeed, maxspeed):
        try:
            element = self.driver.find_element(By.XPATH, xpath)
            for char in str(input):
                element.send_keys(char)
                time.sleep(random.uniform(minspeed, maxspeed))
        except:
            return False
    def alert_confirm(self):
        element = None
        try:
            element = self.driver.switch_to.alert.accept()
        except:
            return False

    def alert_dismiss(self):
        element = None
        try:
            element = self.driver.switch_to.alert.dismiss()
        except:
            return False
    def move_mouse(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
        except:
            return False
    def move_mouseaxis(self, xpath, xaxis, yaxis):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.move_to_element_with_offset(element, xaxis, yaxis).perform()
        except:
            return False
    def mouse_right_click(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            action = ActionChains(self.driver)
            action.context_click(element).perform()
        except:
            return False
    def move_mouse_click(self, movexpath, clickxpath):
        element = None
        try:
            element = self.findelement(movexpath)
            action = ActionChains(self.driver)
            action.move_to_element(element).perform()
            element = self.findelement(clickxpath)
            self.waitforelementdisplay(element, 10)
            action.move_to_element(element).click().perform()
        except:
            return False
    def copytoclipboard(self, element):
        try:
            pyperclip.copy(element)
        except:
            return False
    def pastetoelement(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            element.send_keys(Keys.CONTROL, 'v')
        except:
            return False
    def ScrapeAttribute(self, xpath, type):
        element = None
        try:
            element = self.findelement(xpath).get_attribute(type)
        except:
            return False
        return element
    def elementcount(self, xpath):
        element = None
        try:
            element = len(self.driver.find_elements(By.XPATH, xpath))
        except:
            return False
        return element
    def switch_frame(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            self.driver.switch_to.frame(element)
        except:
            return False
    def clearText(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            if element != None:
                element.clear()
        except:
            return False
    def selectalldelete(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            element.send_keys(Keys.CONTROL, 'a')
            element.send_keys(Keys.BACKSPACE)
        except:
            return False
    def switch_default(self):
        try:
            self.driver.switch_to.default_content()
        except:
            return False
    def generatorEmailVerify(self, email, exp, pos):
        try:
            url = f'https://generator.email/{email}'
            response = requests.get(url, allow_redirects=False)
            loc = response.headers['Location']
            loc = f'http:{loc}'
            response = requests.get(loc, allow_redirects=False)
            loc = (response.headers['Location'])
            response = requests.get(loc, allow_redirects=False)
            loc = (response.headers['Location'])
            cookie = response.cookies['surl']
            cookies = {'surl': cookie}
            response = requests.get(loc, allow_redirects=False, cookies=cookies)
            loc = (response.headers['Location'])
            response = requests.get(loc, allow_redirects=False, cookies=cookies)
            loc = str(response.content)
            regex = exp
            url = re.findall(regex, loc)
            report = html.unescape(url[pos])
            return report
        except:
            return False
    def gettempEmail(self):
        try:
            request = requests.get('https://generator.email').content
            tree = etree.HTML(request)
            email = tree.xpath('//span[@id="email_ch_text"]/text()')
            email = email[0]
            return email
        except:
            return False
    def scroll_to_element(self, xpath):
        element = None
        try:
            element = self.findelement(xpath)
            self.driver.execute_script("arguments[0].scrollIntoView();", element)
        except:
            return False
    def twocaptcha_textcaptcha(self, api, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1, 100)
            file = f".\\{rand}.png"
            element.screenshot(file)
            filename = open(file, 'rb')
            captchafile = {'file': filename}
            data = {'key': api, 'method': 'post'}
            r = requests.post('http://2captcha.com/in.php', files=captchafile, data=data).content.decode('utf-8')
            regex = "(?<=\|).+?(?=$)"
            ID = re.search(regex, r).group()
            if str('OK') in r:
                time.sleep(5)
                r = requests.get(f'http://2captcha.com/res.php?key={api}&action=get&id={ID}').content.decode('utf-8')
            while r == 'CAPCHA_NOT_READY':
                try:
                    time.sleep(5)
                    url = 'https://2captcha.com/res.php'
                    r = requests.get(f'http://2captcha.com/res.php?key={api}&action=get&id={ID}').content.decode(
                        'utf-8')
                except:
                    return r
                if r == 'ERROR_CAPTCHA_UNSOLVABLE':
                    break
                elif r == '':
                    break
            if str('OK') in r:
                element = self.driver.find_element(By.XPATH, input)
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, r).group()
                self.typeinput(input, ID)
        except:
            return False
        filename.close()
        os.remove(file)
    def twocaptcha_textcaptcha_sensitive(self, api, xpath, input):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1, 100)
            file = f".\\{rand}.png"
            element.screenshot(file)
            filename = open(file, 'rb')
            captchafile = {'file': filename}
            data = {'key': api, 'method': 'post', 'regsense':1}
            r = requests.post('http://2captcha.com/in.php', files=captchafile, data=data).content.decode('utf-8')
            regex = "(?<=\|).+?(?=$)"
            ID = re.search(regex, r).group()
            if str('OK') in r:
                time.sleep(5)
                r = requests.get(f'http://2captcha.com/res.php?key={api}&action=get&id={ID}').content.decode('utf-8')
            while r == 'CAPCHA_NOT_READY':
                try:
                    time.sleep(5)
                    url = 'https://2captcha.com/res.php'
                    r = requests.get(f'http://2captcha.com/res.php?key={api}&action=get&id={ID}').content.decode(
                        'utf-8')
                except:
                    return r
                if r == 'ERROR_CAPTCHA_UNSOLVABLE':
                    break
                elif r == '':
                    break
            if str('OK') in r:
                element = self.driver.find_element(By.XPATH, input)
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, r).group()
                self.typeinput(input, ID)
        except:
            return False
        filename.close()
        os.remove(file)
    def twocaptcha_recaptcha2(self, api):
        try:
            txt = ''
            curr_url = self.driver.current_url
            self.driver.switch_to.default_content()
            scrape = self.elementcount('//div[@class="g-recaptcha"]')
            if scrape != 0:
                txt = self.ScrapeAttribute('//div[@class="g-recaptcha"]', 'data-sitekey')
            else:
                self.driver.switch_to.default_content()
                scrape = self.elementcount('(//iframe[contains(@src,"recaptcha")])[1]')
                if scrape != 0:
                    txt = self.ScrapeAttribute('(//iframe[contains(@src,"recaptcha")])[1]', 'outerHTML')
                    regex = "(?<=k\=).+?(?=\&)"
                    txt = re.search(regex, txt).group()
            url = 'https://2captcha.com/in.php'
            response = requests.get(url, params={'key': api, 'method': 'userrecaptcha', 'googlekey': txt, 'pageurl': curr_url}).content.decode('utf-8')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                element = self.driver.find_element(By.XPATH, '//*[@name="g-recaptcha-response"]')
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                self.driver.execute_script(f"arguments[0].innerHTML = '{ID}'", element)

        except:
            return False
    def twocaptcha_recaptchacallback(self, api):
        try:
            curr_url = self.driver.current_url
            self.driver.switch_to.default_content()
            scrape = self.elementcount('//div[@class="g-recaptcha"]')
            if scrape != 0:
                txt = self.ScrapeAttribute('//div[@class="g-recaptcha"]', 'data-sitekey')
            else:
                self.driver.switch_to.default_content()
                scrape = self.elementcount('(//iframe[contains(@src,"recaptcha")])[1]')
                if scrape != 0:
                    txt = self.ScrapeAttribute('(//iframe[contains(@src,"recaptcha")])[1]', 'outerHTML')
                    regex = "(?<=k\=).+?(?=\&)"
                    txt = re.search(regex, txt).group()
            url = 'https://2captcha.com/in.php'
            response = requests.get(url, params={'key': api, 'method': 'userrecaptcha', 'googlekey': txt, 'pageurl': curr_url}).content.decode('utf-8)')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                element = self.driver.find_element(By.XPATH, '//textarea[@id="g-recaptcha-response"]')
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                callback = self.callback()
                if len(callback) == 0:
                    callback = self.callback2()
                self.driver.execute_script(f"arguments[0].innerHTML = '{ID}'", element)
                run = f'''
                return {callback}('{ID}');
                '''
                self.driver.execute_script(run)
        except:
            return False
    def twocaptcha_recaptchacallback2(self, api, txt, callback):
        try:
            curr_url = self.driver.current_url
            url = 'https://2captcha.com/in.php'
            response = requests.get(url, params={'key': api, 'method': 'userrecaptcha', 'googlekey': txt,
                                                 'pageurl': curr_url}).content.decode('utf-8)')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                self.driver.switch_to.default_content()
                element = self.driver.find_element(By.XPATH, '//*[@name="g-recaptcha-response"]')
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                self.driver.execute_script(f"arguments[0].innerHTML = '{ID}'", element)
                run = f'''
                return {callback}('{ID}');
                '''
                # run = f'''{callback}('{ID}');'''
                callback = self.driver.execute_script(run)
                return callback
        except:
            return False
    def twocaptcha_recaptchaenterprise(self, api):
        try:
            txt = ''
            curr_url = self.driver.current_url
            self.driver.switch_to.default_content()
            scrape = self.elementcount('//div[@class="g-recaptcha"]')
            if scrape != 0:
                txt = self.ScrapeAttribute('//div[@class="g-recaptcha"]', 'data-sitekey')
            else:
                self.driver.switch_to.default_content()
                scrape = self.elementcount('(//iframe[contains(@src,"recaptcha")])[1]')
                if scrape != 0:
                    txt = self.ScrapeAttribute('(//iframe[contains(@src,"recaptcha")])[1]', 'outerHTML')
                    regex = "(?<=k\=).+?(?=\&)"
                    txt = re.search(regex, txt).group()
            url = 'https://2captcha.com/in.php'
            response = requests.get(url, params={'key': api, 'method': 'userrecaptcha', 'enterprise': 1, 'action': "verify",'min_score': "0.3",'invisible': 1, 'googlekey': txt, 'pageurl': curr_url}).content.decode('utf-8)')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                self.driver.switch_to.default_content()
                element = self.driver.find_element(By.XPATH, '//*[@name="g-recaptcha-response"]')
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                self.driver.execute_script(f"arguments[0].innerHTML = '{ID}'", element)
                time.sleep(3)
                dataCallback = self.callback()
                if len(dataCallback) == 0:
                    datacallback = self.callback2()
                run = f'''
                return {dataCallback}('{ID}');
                '''
                # run = f'''{callback}('{ID}');'''
                onCallback = self.driver.execute_script(run)
                return onCallback
        except:
            return False
    def funcaptcha(self, api):
        try:
            self.switch_default()
            self.switch_frame('//iframe[@id="enforcementFrame"]')
            element = self.ScrapeAttribute('//input[@name="fc-token"]', 'value')
            pk = re.search("""(?<=pk\=).+?(?=\|)""", element).group()
            surl = re.search("""(?<=surl\=).+?(?=$)""", element).group()
            surl = urllib.parse.unquote(surl)
            curr_url = self.driver.current_url
            url = 'https://2captcha.com/in.php'
            response = requests.get(url, params={'key': api, 'method': 'funcaptcha', 'publickey': pk, 'surl': surl, 'pageurl': curr_url}).content.decode('utf-8)')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                print(ID)
                script = """
                document.getElementById('FunCaptcha-Token').value = decodeURIComponent('{0}');
                document.getElementById('verification-token').value = decodeURIComponent('{0}');
                """
                self.driver.execute_script(script)
        except:
            return False
    def twocaptcha_recaptchav3(self, api, callback):
        try:
            element = self.ScrapeAttribute('//script[contains(@src,"api.js")]', 'outerHTML')
            regex = "(?<=render\=).+?(?=\")"
            txt = re.search(regex, element).group()
            curr_url = self.driver.current_url
            url = 'https://2captcha.com/in.php'
            response = requests.get(url,
                                    params={'key': api, 'method': 'userrecaptcha', 'version': 'v3', 'action': 'verify',
                                            'min_score': '0.3', 'googlekey': txt, 'pageurl': curr_url}).content.decode('utf-8)')
            if str('OK') in response:
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                time.sleep(15)
                url = 'https://2captcha.com/res.php'
                response = requests.get(url,
                                        params={'key': api, 'action': 'get', 'id': ID, 'json': 0}).content.decode(
                    'utf-8')
                while response == 'CAPCHA_NOT_READY':
                    try:
                        time.sleep(5)
                        url = 'https://2captcha.com/res.php'
                        response = requests.get(url, params={'key': api, 'action': 'get', 'id': ID,
                                                             'json': 0}).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR_CAPTCHA_UNSOLVABLE':
                        break
                    elif response is None:
                        break
            if str('OK') in response:
                # self.switch_frame('(//iframe[@title="reCAPTCHA"])[1]')
                # self.switch_default()
                # element = self.driver.find_element(By.XPATH, '(//*[@name="g-recaptcha-response"])[1]')
                element = self.findelement('(//*[@name="g-recaptcha-response"])[1]')
                regex = "(?<=\|).+?(?=$)"
                ID = re.search(regex, response).group()
                self.driver.execute_script(f"arguments[0].innerHTML = '{ID}'", element)
                run = f'''
                return {callback}('{ID}');
                '''
                onReturn = self.driver.execute_script(run)
                return onReturn
        except:
            return False
    def imagetyperz_textcaptcha(self, api, xpath,input):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1, 100)
            file = f".\\{rand}.png"
            element.screenshot(file)
            filename = open(file, 'rb')
            captchafile = {'file': filename}
            encod = base64.b64encode(filename.read())
            encode = encod.split()
            data = {'token': api, 'file': encod, 'action': 'UPLOADCAPTCHA'}
            r = requests.post('http://captchatypers.com/Forms/UploadFileAndGetTextNEWToken.ashx', data=data).content.decode('utf-8')
            regex = "(?<=\|).+?(?=$)"
            ID = re.search(regex, r).group()
            if len(ID) != 0:
                element = self.driver.find_element(By.XPATH, input)
                self.typeinput(input, ID)
        except:
            return False
        filename.close()
        os.remove(file)
    def imagetyperz_textcaptcha_sensitive(self, api, xpath,input):
        element = None
        try:
            element = self.findelement(xpath)
            rand = random.randint(1, 100)
            file = f".\\{rand}.png"
            element.screenshot(file)
            filename = open(file, 'rb')
            captchafile = {'file': filename}
            encod = base64.b64encode(filename.read())
            encode = encod.split()
            data = {'token': api, 'file': encod, 'action': 'UPLOADCAPTCHA', 'iscase':'true'}
            r = requests.post('http://captchatypers.com/Forms/UploadFileAndGetTextNEWToken.ashx', data=data).content.decode('utf-8')
            regex = "(?<=\|).+?(?=$)"
            ID = re.search(regex, r).group()
            if len(ID) != 0:
                element = self.driver.find_element(By.XPATH, input)
                self.typeinput(input, ID)
        except:
            return False
        filename.close()
        os.remove(file)
    def imagetyperz_recaptcha2(self, api):
        try:
            txt = ''
            curr_url = self.driver.current_url
            self.driver.switch_to.default_content()
            scrape = self.elementcount('//div[@class="g-recaptcha"]')
            if scrape != 0:
                txt = self.ScrapeAttribute('//div[@class="g-recaptcha"]', 'data-sitekey')
            else:
                self.driver.switch_to.default_content()
                scrape = self.elementcount('(//iframe[contains(@src,"recaptcha")])[1]')
                if scrape != 0:
                    txt = self.ScrapeAttribute('(//iframe[contains(@src,"recaptcha")])[1]', 'outerHTML')
                    regex = "(?<=k\=).+?(?=\&)"
                    txt = re.search(regex, txt).group()
            url = 'http://captchatypers.com/captchaapi/UploadRecaptchaToken.ashx'
            params = {'token': api, 'pageurl': curr_url, 'googlekey': txt, 'action': 'UPLOADCAPTCHA'}
            response = requests.post(url, data=params).content.decode('utf-8')
            response = int(response)
            if type(response) is int:
                ID = response
                time.sleep(15)
                url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                response = requests.post(url, data=params).content.decode('utf-8')
                while response == 'ERROR: NOT_DECODED':
                    try:
                        time.sleep(5)
                        url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                        params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                        response = requests.post(url, data=params).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR: IMAGE_TIMED_OUT':
                        break
                    elif response is None:
                        break
            if 'ERROR:' not in response:
                element = self.driver.find_element(By.XPATH, '//*[@name="g-recaptcha-response"]')
                self.driver.execute_script(f"arguments[0].innerHTML = '{response}'", element)
        except:
            return False
    def imagetyperz_recaptchacallback(self, api):
        try:
            txt = ''
            curr_url = self.driver.current_url
            self.driver.switch_to.default_content()
            scrape = self.elementcount('//div[@class="g-recaptcha"]')
            if scrape != 0:
                txt = self.ScrapeAttribute('//div[@class="g-recaptcha"]', 'data-sitekey')
            else:
                self.driver.switch_to.default_content()
                scrape = self.elementcount('(//iframe[contains(@src,"recaptcha")])[1]')
                if scrape != 0:
                    txt = self.ScrapeAttribute('(//iframe[contains(@src,"recaptcha")])[1]', 'outerHTML')
                    regex = "(?<=k\=).+?(?=\&)"
                    txt = re.search(regex, txt).group()
            url = 'http://captchatypers.com/captchaapi/UploadRecaptchaToken.ashx'
            params = {'token': api, 'pageurl': curr_url, 'googlekey': txt, 'action': 'UPLOADCAPTCHA'}
            response = requests.get(url, data=params).content.decode('utf-8')
            response = int(response)
            if type(response) is int:
                ID = response
                time.sleep(15)
                url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                response = requests.get(url, data=params).content.decode('utf-8')
                while response == 'ERROR: NOT_DECODED':
                    try:
                        time.sleep(5)
                        url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                        params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                        response = requests.get(url, data=params).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR: IMAGE_TIMED_OUT':
                        break
                    elif response is None:
                        break
            if 'ERROR:' not in response:
                element = self.driver.find_element(By.XPATH, '//*[@name="g-recaptcha-response"]')
                callback = self.callback()
                if len(callback) == 0:
                    callback = self.callback2()
                self.driver.execute_script(f"arguments[0].innerHTML = '{response}'", element)
                run = f'''
                return {callback}('{response}');
                '''
                self.driver.execute_script(run)
        except:
            return False
    def imagetyperz_recaptchav3(self, api, callback):
        try:
            element = self.ScrapeAttribute('//script[contains(@src,"api.js")]', 'outerHTML')
            regex = "(?<=render\=).+?(?=\")"
            txt = re.search(regex, element).group()
            curr_url = self.driver.current_url
            url = 'http://captchatypers.com/captchaapi/UploadRecaptchaToken.ashx'
            params = {'token': api, 'pageurl': curr_url, 'googlekey': txt, 'action': 'UPLOADCAPTCHA', 'recaptchatype': 3,
                      'score': '0.3'}
            response = requests.get(url, data=params).content.decode('utf-8)')
            response = int(response)
            if type(response) is int:
                ID = response
                time.sleep(15)
                url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                response = requests.get(url, data=params).content.decode('utf-8')
                while response == 'ERROR: NOT_DECODED':
                    try:
                        time.sleep(5)
                        url = 'http://captchatypers.com/captchaapi/GetRecaptchaTextToken.ashx'
                        params = {'token': api, 'captchaID': ID, 'action': 'GETTEXT'}
                        response = requests.get(url, data=params).content.decode('utf-8')
                    except:
                        return response.content.decode('utf-8')
                    if response == 'ERROR: IMAGE_TIMED_OUT':
                        break
                    elif response is None:
                        break
            if 'ERROR:' not in response:
                # self.switch_frame('(//iframe[@title="reCAPTCHA"])[1]')
                # self.switch_default()
                # element = self.driver.find_element(By.XPATH, '(//*[@name="g-recaptcha-response"])[1]')
                element = self.findelement('(//*[@name="g-recaptcha-response"])[1]')
                self.driver.execute_script(f"arguments[0].innerHTML = '{response}'", element)
                run = f'''
                return {callback}('{response}');
                '''
                onReturn = self.driver.execute_script(run)
                return onReturn
        except:
            return False
    def textcaptcha(self, service, api, xpath, input):
        try:
            if service == '2 Captcha':
                self.twocaptcha_textcaptcha(api,xpath, input)
            else:
                self.imagetyperz_textcaptcha(api,xpath, input)
        except:
            return False
    def textcaptcha_sensitive(self, service, api, xpath,input):
        try:
            if service == '2 Captcha':
                self.twocaptcha_textcaptcha(api, xpath, input)
            else:
                self.imagetyperz_textcaptcha(api, xpath, input)
        except:
            return False
    def recaptcha2(self, service, api):
        try:
            if service == '2 Captcha':
                self.twocaptcha_recaptcha2(api)
            else:
                self.imagetyperz_recaptcha2(api)
        except:
            return False
    def recaptchacallback(self, service, api):
        try:
            if service == '2 Captcha':
                self.twocaptcha_recaptchacallback(api)
            else:
                self.imagetyperz_recaptchacallback(api)
        except:
            return False
    def recaptchav3(self, service, api, callback):
        try:
            if service == '2 Captcha':
                self.twocaptcha_recaptchav3(api, callback)
            else:
                self.imagetyperz_recaptchav3(api, callback)
        except:
            return False
class Proxy():
    def proxy_auth(self, proxy, port, proxyU, proxyP):
        manifest_json = """
        {
            "version": "1.0.0",
            "manifest_version": 2,
            "name": "Chrome Proxy",
            "permissions": [
                "proxy",
                "tabs",
                "unlimitedStorage",
                "storage",
                "<all_urls>",
                "webRequest",
                "webRequestBlocking"
            ],
            "background": {
                "scripts": ["background.js"]
            },
            "minimum_chrome_version":"22.0.0"
        }
        """

        background_js = """
        var config = {
                mode: "fixed_servers",
                rules: {
                  singleProxy: {
                    scheme: "http",
                    host: "%s",
                    port: parseInt(%s)
                  },
                  bypassList: ["foobar.com"]
                }
              };

        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

        function callbackFn(details) {
            return {
                authCredentials: {
                    username: "%s",
                    password: "%s"
                }
            };
        }

        chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ['blocking']
        );
        """ % (proxy, port, proxyU, proxyP)
        rand = random.randint(0000, 9999)
        temp = tempfile.gettempdir()
        pluginfile = rf'{temp}/proxy_auth_plugin{rand}.zip'
        with zipfile.ZipFile(pluginfile, 'w') as zp:
            zp.writestr("manifest.json", manifest_json)
            zp.writestr("background.js", background_js)
        return pluginfile
